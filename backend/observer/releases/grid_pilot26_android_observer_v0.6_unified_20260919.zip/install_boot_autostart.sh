#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$HOME/grid-pilot26-observer"
BOOT_DIR="$HOME/.termux/boot"
BOOT_FILE="$BOOT_DIR/00-grid-pilot26-observer"
mkdir -p "$BOOT_DIR"
cat > "$BOOT_FILE" <<'BOOT'
#!/data/data/com.termux/files/usr/bin/bash
sleep 20
cd "$HOME/grid-pilot26-observer" || exit 1
./start_observer.sh >> logs/boot.log 2>&1
BOOT
chmod 700 "$BOOT_FILE"
echo "BOOT AUTOSTART SCRIPT INSTALLED: $BOOT_FILE"
echo "REQUIRES: Termux:Boot installed and opened once; Android/MIUI battery mode set to unrestricted and Termux autostart allowed."
