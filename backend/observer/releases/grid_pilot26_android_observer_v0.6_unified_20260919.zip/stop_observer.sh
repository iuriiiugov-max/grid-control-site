#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$HOME/grid-pilot26-observer"
PIDFILE="$ROOT/observer.pid"
LOOP_PIDFILE="$ROOT/observer_loop.pid"

if [ -f "$LOOP_PIDFILE" ]; then
  pid="$(cat "$LOOP_PIDFILE" 2>/dev/null || true)"
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
  fi
fi
if [ -f "$PIDFILE" ]; then
  pid="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null || true
    sleep 1
  fi
fi
rm -f "$PIDFILE" "$LOOP_PIDFILE"
termux-wake-unlock >/dev/null 2>&1 || true
echo "OBSERVER STOPPED"
