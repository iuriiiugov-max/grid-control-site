#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
command -v curl >/dev/null 2>&1 || { echo "curl missing/broken"; exit 1; }
curl --version >/dev/null
command -v openssl >/dev/null 2>&1 || { echo "openssl missing"; exit 1; }
command -v python >/dev/null 2>&1 || pkg install -y python
command -v rclone >/dev/null 2>&1 || pkg install -y rclone
python -m pip install --upgrade requests
mkdir -p "$HOME/grid-pilot26-observer/config" "$HOME/grid-pilot26-observer/out" "$HOME/grid-pilot26-observer/logs"
echo "DEPENDENCIES READY"
