#!/data/data/com.termux/files/usr/bin/bash
set -u
ROOT="$HOME/grid-pilot26-observer"
cd "$ROOT" || exit 1
mkdir -p logs out
CONFIG="$ROOT/config/config.json"
DRIVE_TARGET='gdrive:CRYPTO_MASTER/GRID_PILOT26_COMMISSIONING/GRID_PILOT26_ANDROID_OBSERVER/latest.json'

read_cfg_int() {
  local key="$1" default="$2"
  python - "$CONFIG" "$key" "$default" <<'PY'
import json, sys
p, key, default = sys.argv[1], sys.argv[2], int(sys.argv[3])
try:
    d=json.load(open(p, encoding='utf-8'))
    print(int(d.get(key, default)))
except Exception:
    print(default)
PY
}

DEFAULT_INTERVAL_SEC="$(read_cfg_int observerIntervalSec 60)"
TTL_SEC="$(read_cfg_int privateStateTtlSec 120)"
INTERVAL_SEC="${INTERVAL_SEC:-$DEFAULT_INTERVAL_SEC}"

case "$INTERVAL_SEC:$TTL_SEC" in
  *[!0-9:]*|:*|*:) echo "INVALID cadence values interval=$INTERVAL_SEC ttl=$TTL_SEC" >&2; exit 2 ;;
esac
if [ "$INTERVAL_SEC" -le 0 ] || [ "$TTL_SEC" -le 0 ] || [ "$INTERVAL_SEC" -ge "$TTL_SEC" ]; then
  echo "UNSAFE cadence: interval=$INTERVAL_SEC must be < ttl=$TTL_SEC" >&2
  exit 2
fi

snapshot_is_fresh() {
  python - "$ROOT/out/latest.json" "$TTL_SEC" <<'PY'
import json, pathlib, sys, time
p=pathlib.Path(sys.argv[1]); ttl=int(sys.argv[2])
if not p.is_file():
    raise SystemExit(10)
try:
    d=json.loads(p.read_text(encoding='utf-8'))
except Exception:
    raise SystemExit(11)
if d.get('mode') not in ('READ_ONLY_GET_ONLY_PROXY_REQUIRED','READ_ONLY_GET_ONLY'):
    raise SystemExit(12)
if not d.get('snapshotId') or not d.get('capturedAtEpochMs'):
    raise SystemExit(13)
timing=d.get('timing') or {}
embedded_ttl=timing.get('privateStateTtlSec')
if type(embedded_ttl) is not int or embedded_ttl <= 0:
    raise SystemExit(14)
if embedded_ttl != ttl:
    raise SystemExit(15)
age=max(0, int(time.time()*1000)-int(d['capturedAtEpochMs']))//1000
if age > embedded_ttl:
    raise SystemExit(16)
print(age)
PY
}

echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) loop_start interval_sec=$INTERVAL_SEC ttl_sec=$TTL_SEC drive_target=$DRIVE_TARGET" >> logs/loop.log

while true; do
  cycle_start="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  python collector.py
  collector_rc=$?
  upload_rc=90
  upload_status="SKIPPED"
  snapshot_age="NA"

  # collector_rc=2 is semantic fail-closed: a fresh snapshot was written but
  # authoritative coverage is incomplete/unknown (for example gridBotRegistry).
  # It must still be published so downstream readers see fresh account state and
  # the explicit RED/UNKNOWN reason. Only missing/invalid/stale snapshots block upload.
  if [ "$collector_rc" -eq 0 ] || [ "$collector_rc" -eq 2 ]; then
    if snapshot_age="$(snapshot_is_fresh 2>>logs/loop.log)"; then
      if [ -f "$HOME/.config/rclone/rclone.conf" ] && command -v rclone >/dev/null 2>&1 && rclone listremotes 2>/dev/null | grep -qx 'gdrive:'; then
        if rclone copyto "$ROOT/out/latest.json" "$DRIVE_TARGET" --drive-use-trash=false >> logs/rclone.log 2>&1; then
          upload_rc=0
          upload_status="OK"
        else
          upload_rc=$?
          upload_status="FAILED"
        fi
      else
        upload_status="RCLONE_NOT_READY"
      fi
    else
      upload_rc=$?
      upload_status="SKIP_STALE_OR_INVALID_SNAPSHOT"
    fi
  else
    upload_status="SKIP_COLLECTOR_HARD_FAILED"
  fi

  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) cycle_start=$cycle_start collector_rc=$collector_rc snapshot_age_sec=$snapshot_age upload_status=$upload_status upload_rc=$upload_rc" >> logs/loop.log
  sleep "$INTERVAL_SEC"
done
