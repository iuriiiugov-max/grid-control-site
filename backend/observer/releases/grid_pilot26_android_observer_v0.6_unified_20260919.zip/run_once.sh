#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$HOME/grid-pilot26-observer"
python collector.py
