# GRID Pilot26 Android Observer v0.6

Unified baseline release.

## Consolidated lineage

- v0.4 collector/core and current private-state schema producer.
- v0.5 supervisor, hardened run loop, start/stop/status tooling and boot/autostart support.
- v0.5.1 upload fix: controlled fail-closed (`collector_rc=2`) snapshots are uploaded when fresh/valid so downstream readers receive explicit RED/UNKNOWN state instead of stale silence.

## v0.6 change

No trading behavior is added. The existing verified components are consolidated into one release and the collector's emitted version is changed to `0.6`, eliminating split core/runtime version labels.

Safety baseline: READ_ONLY / AUTO_EXECUTION_OFF.
