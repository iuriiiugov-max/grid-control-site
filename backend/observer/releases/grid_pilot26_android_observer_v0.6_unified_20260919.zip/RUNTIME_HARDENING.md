# Observer v0.6 unified runtime

Observer v0.6 is the unified release that folds the previously split versioning into one package:

- collector/core previously identified as v0.4;
- supervisor/runtime hardening introduced in package v0.5;
- Drive upload fail-closed visibility fix introduced in package v0.5.1.

## Runtime behavior

- Exchange behavior remains READ_ONLY.
- AUTO_EXECUTION remains OFF.
- `observer_supervisor.sh` restarts a dead loop and restarts a live-but-stale loop.
- `run_loop.sh` publishes a fresh valid snapshot for collector return codes 0 and 2.
- Return code 2 is semantic fail-closed: the snapshot is fresh but authoritative coverage is incomplete/unknown; publishing it lets downstream readers see current state plus explicit RED/UNKNOWN reasons.
- Hard collector failures do not refresh Drive with an old snapshot.
- Invalid or stale snapshots are never uploaded as fresh state.
- `install_boot_autostart.sh` installs the Termux:Boot startup script. Android/MIUI still requires Termux:Boot to be installed/opened once and device battery/autostart restrictions to permit it.

## Versioning rule

From this release onward, `observerVersion` identifies the complete Observer release, not only `collector.py`.
The package version and the version emitted into `latest.json` must match.
