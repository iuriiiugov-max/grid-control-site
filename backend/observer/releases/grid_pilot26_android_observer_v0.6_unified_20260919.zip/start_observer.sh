#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
ROOT="$HOME/grid-pilot26-observer"
cd "$ROOT"
mkdir -p logs
PIDFILE="$ROOT/observer.pid"
LOOP_PIDFILE="$ROOT/observer_loop.pid"

if [ -f "$PIDFILE" ]; then
  old="$(cat "$PIDFILE" 2>/dev/null || true)"
  if [ -n "$old" ] && kill -0 "$old" 2>/dev/null; then
    echo "OBSERVER SUPERVISOR ALREADY RUNNING pid=$old"
    exit 0
  fi
  rm -f "$PIDFILE" "$LOOP_PIDFILE"
fi

python collector.py --self-test
interval="$(python - <<'PY'
import json
from pathlib import Path
p=Path.home()/"grid-pilot26-observer/config/config.json"
d=json.loads(p.read_text(encoding="utf-8"))
print(int(d.get("observerIntervalSec",60)))
PY
)"
ttl="$(python - <<'PY'
import json
from pathlib import Path
p=Path.home()/"grid-pilot26-observer/config/config.json"
d=json.loads(p.read_text(encoding="utf-8"))
print(int(d.get("privateStateTtlSec",120)))
PY
)"
if [ "$interval" -le 0 ] || [ "$ttl" -le 0 ] || [ "$interval" -ge "$ttl" ]; then
  echo "UNSAFE cadence: interval=$interval must be < ttl=$ttl" >&2
  exit 2
fi

termux-wake-lock >/dev/null 2>&1 || true
nohup ./observer_supervisor.sh >> logs/supervisor.nohup.log 2>&1 < /dev/null &
echo $! > "$PIDFILE"
chmod 600 "$PIDFILE"
sleep 1
if ! kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "OBSERVER SUPERVISOR FAILED TO START" >&2
  exit 3
fi
echo "OBSERVER SUPERVISOR STARTED pid=$(cat "$PIDFILE") interval=${interval}s ttl=${ttl}s"
