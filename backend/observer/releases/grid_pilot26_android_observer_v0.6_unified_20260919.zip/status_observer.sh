#!/data/data/com.termux/files/usr/bin/bash
set -u
ROOT="$HOME/grid-pilot26-observer"
PIDFILE="$ROOT/observer.pid"
LOOP_PIDFILE="$ROOT/observer_loop.pid"

show_pid() {
  local label="$1" file="$2"
  if [ -f "$file" ]; then
    local pid
    pid="$(cat "$file" 2>/dev/null || true)"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
      echo "$label RUNNING pid=$pid"
    else
      echo "$label NOT RUNNING (stale pidfile)"
    fi
  else
    echo "$label NOT RUNNING"
  fi
}

show_pid "SUPERVISOR" "$PIDFILE"
show_pid "LOOP" "$LOOP_PIDFILE"

if [ -f "$ROOT/out/latest.json" ]; then
  python - <<'PY'
import json, pathlib, time
p=pathlib.Path.home()/"grid-pilot26-observer/out/latest.json"
d=json.loads(p.read_text())
age=max(0,int(time.time()*1000)-int(d.get("capturedAtEpochMs",0)))//1000
print("latest:", d.get("capturedAtUtc"), "age_sec=", age, "snapshotId=", d.get("snapshotId"), "schema=", d.get("schema"), "mode=", d.get("mode"), "auth_ok=", d.get("authHealth",{}).get("ok"), "health=", d.get("health",{}).get("status"))
print("coverage:", json.dumps(d.get("coverage",{}), ensure_ascii=False, separators=(",",":")))
PY
fi
[ -f "$ROOT/logs/supervisor.log" ] && echo "last_supervisor: $(tail -n 1 "$ROOT/logs/supervisor.log")"
[ -f "$ROOT/logs/loop.log" ] && echo "last_loop: $(tail -n 1 "$ROOT/logs/loop.log")"
