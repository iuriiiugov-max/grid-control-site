#!/data/data/com.termux/files/usr/bin/bash
set -u
ROOT="$HOME/grid-pilot26-observer"
cd "$ROOT" || exit 1
mkdir -p logs
CONFIG="$ROOT/config/config.json"
LOOP_PIDFILE="$ROOT/observer_loop.pid"
CHECK_SEC="${SUPERVISOR_CHECK_SEC:-30}"

read_cfg_int() {
  local key="$1" default="$2"
  python - "$CONFIG" "$key" "$default" <<'PY'
import json, sys
p, key, default = sys.argv[1], sys.argv[2], int(sys.argv[3])
try:
    d=json.load(open(p, encoding='utf-8'))
    print(int(d.get(key, default)))
except Exception:
    print(default)
PY
}

INTERVAL_SEC="$(read_cfg_int observerIntervalSec 60)"
TTL_SEC="$(read_cfg_int privateStateTtlSec 120)"
# Allow one missed cycle, but do not tolerate a dead/hung collector indefinitely.
STALE_RESTART_SEC=$(( TTL_SEC * 2 ))
if [ "$STALE_RESTART_SEC" -lt $(( INTERVAL_SEC * 3 )) ]; then
  STALE_RESTART_SEC=$(( INTERVAL_SEC * 3 ))
fi

child=""
cleanup() {
  if [ -n "${child:-}" ] && kill -0 "$child" 2>/dev/null; then
    kill "$child" 2>/dev/null || true
    wait "$child" 2>/dev/null || true
  fi
  rm -f "$LOOP_PIDFILE"
}
trap cleanup EXIT INT TERM HUP

start_loop() {
  ./run_loop.sh >> logs/nohup.log 2>&1 &
  child=$!
  printf '%s\n' "$child" > "$LOOP_PIDFILE"
  chmod 600 "$LOOP_PIDFILE"
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) supervisor_restart loop_pid=$child" >> logs/supervisor.log
}

latest_age_sec() {
  python - "$ROOT/out/latest.json" <<'PY'
import json, pathlib, sys, time
p=pathlib.Path(sys.argv[1])
if not p.is_file():
    print(999999); raise SystemExit
try:
    d=json.loads(p.read_text(encoding='utf-8'))
    ms=int(d.get('capturedAtEpochMs',0))
    print(max(0,int(time.time()*1000)-ms)//1000 if ms > 0 else 999999)
except Exception:
    print(999999)
PY
}

start_loop
while true; do
  sleep "$CHECK_SEC"
  if ! kill -0 "$child" 2>/dev/null; then
    wait "$child" 2>/dev/null || true
    start_loop
    continue
  fi

  age="$(latest_age_sec)"
  case "$age" in *[!0-9]*) age=999999 ;; esac
  if [ "$age" -gt "$STALE_RESTART_SEC" ]; then
    echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) supervisor_stale age_sec=$age threshold_sec=$STALE_RESTART_SEC loop_pid=$child action=restart" >> logs/supervisor.log
    kill "$child" 2>/dev/null || true
    sleep 2
    if kill -0 "$child" 2>/dev/null; then kill -9 "$child" 2>/dev/null || true; fi
    wait "$child" 2>/dev/null || true
    start_loop
  fi
done
